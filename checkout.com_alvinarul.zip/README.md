# checkout-test
Checkout.com API Test

Greetings. I am Alvin Arulselvan. Here is the guide to testing my Checkout API Test.

Visit https://checkout-test-alvinarul.netlify.app to test my application.

The code is also on github @ https://github.com/tomorrowknight/checkout-test

Please ignore my myriad of pushes because I was testing directly on netlify by pushing from github.

Successful Credentials:

Name: Any name
Email: Any email
Card Number: 4242 4242 4242 4242
Date and Month of Expiry: Any future date
CVV/CVV2: 100 

Failing Credentials:

Name: Any name
Email: Any email
Card Number: 4242 4242 4242 4242
Date and Month of Expiry: Any future date
CVV/CVV2: 234

Validation done for empty name and email fields.
Success and Fail Pages have payment details.
Done with HTML/JS/JQuery/CSS and of course, Checkout.com API

For more information contact me at alvinarulselvan@gmail.com for information.

You can also test this locally but the payment details to link to success and failure will not work unless you hook it up to some Web Application server.



